# Pretrained vocab files for GPT-2/3

This directory contains the pretrained vocab files for GPT-2.
Files are from [huggingface/transformers](https://github.com/huggingface/transformers/blob/main/src/transformers/models/gpt2/tokenization_gpt2.py#L39) and use the 'gpt2-xl' version.
